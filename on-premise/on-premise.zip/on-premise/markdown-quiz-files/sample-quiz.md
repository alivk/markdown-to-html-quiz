# MaxSoft Quiz

---
1. MaxSoft is a software company.
    - (x) True
    - ( ) False

2. The domain of MaxSoft is test automation framework development.
    - (x) True
    - ( ) False 

3. What are the test automation frameworks developed by MaxSoft?
    - [x] IntelliAPI
    - [x] WebBot
    - [ ] Gauge
	- [ ] Selenium

4. Who is the Co-Founder of MaxSoft?
    - R:= Osanda
